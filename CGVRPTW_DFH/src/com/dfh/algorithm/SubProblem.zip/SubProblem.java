package com.dfh.algorithm;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import com.dfh.instance.*;


public class SubProblem {
	
	public double reducedCost;
	public Map<Customer,Double> rmpDualValues;
	public VrptwInstance vrptwInstance;
	private Route route;
	private List<Route> searchRoutes;
	
	private boolean angleStatus;
	private boolean greedyStatus;
	private boolean randomStatus;
	
	private Route [][]anglesRoutes;
	

	public SubProblem() {
		angleStatus  = true;
		greedyStatus = true;
		randomStatus = true;
		searchRoutes = new ArrayList<>();
	}
	
	public SubProblem(VrptwInstance vrptwInstance) {
		this.vrptwInstance = vrptwInstance;
		angleStatus  = true;
		greedyStatus = true;
		randomStatus = true;
		searchRoutes = new ArrayList<>();
		
		buildRoutesAngles();
		buildRouteGreedy();
	}
	
	public void solve() {
		
		if(this.angleStatus) {
			searchRoutesAngles();
			return;
		}
		
		if(this.greedyStatus) {
			buildRouteGreedy();
		}
		
		
	}
	
	public void buildRouteGreedy() {
		for(Route r:searchRoutes) {
			System.out.println(r.toString());
		}
	}
	
	public void searchRoutesAngles() {
		
		
		
		this.reducedCost = Integer.MAX_VALUE;
		for(int i = 0; i < vrptwInstance.getCustomersNr(); ++i) {
			for(int j = 2; j <= vrptwInstance.getCustomersNr(); ++j) {
				double reducedCost = calculateReducedCost(this.anglesRoutes[i][j]);
				//System.out.println("route["+i+", "+j+"] ReducedCost = "+this.reducedCost);
				if(reducedCost < this.reducedCost) {
					this.reducedCost = reducedCost;
					this.route = this.anglesRoutes[i][j];
				}
			}
		}
		
		if(this.reducedCost > this.vrptwInstance.parameters.zero_reduced_cost) {
			this.angleStatus = false;
		}
	}
	
	public void buildRoutesAngles() {
		//anglesRoutes[i][j] >>> start from customer i, 取j个合法的构成一条route j should be 2 To CustomersNr
		this.anglesRoutes = new Route[vrptwInstance.getCustomersNr()][vrptwInstance.getCustomersNr()+1];

		//simple heuristic for building routes
		for(int i = 0; i < vrptwInstance.getCustomersNr(); ++i) {
			this.anglesRoutes[i] = new Route[vrptwInstance.getCustomersNr()+1];
			int lastSize = 0;
			for(int j = 2; j <= vrptwInstance.getCustomersNr(); ++j) {
				this.anglesRoutes[i][j] = buildOneLegalRoute(i, j);
				
				if(j == 2) {
					Route oneRoute = buildOneLegalRoute(i, j);
					lastSize = oneRoute.getCustomersLength();
					searchRoutes.add(oneRoute);
				}else {
					Route oneRoute = buildOneLegalRoute(i, j);
					int thisSize = oneRoute.getCustomersLength();
					
					if(lastSize != thisSize) {
						searchRoutes.add(oneRoute);
						lastSize = thisSize;
					}
					
				}
			}
		}
		
	}
	
	public void calculateReducedCost() {
		if(this.route.isEmpty()) {
			System.out.println(" route is empty, what the hell are you doing ??? ");
		}else {
			double cBaj = 0;
			for(Customer cust : rmpDualValues.keySet()) {
				cBaj += rmpDualValues.get(cust) * route.a(cust);
			}
			this.reducedCost = route.getCost().getTravelTime() - cBaj;
		}
	}
	
	public double calculateReducedCost(Route route) {
		if(route.isEmpty()) {
			System.out.println(" route is empty, what the hell are you doing ??? ");
			return 0;
		}else {
			double reducedCost = 0;
			double cBaj = 0;
			for(Customer cust : rmpDualValues.keySet()) {
				cBaj += rmpDualValues.get(cust) * route.a(cust);
			}
			reducedCost = route.getCost().getTravelTime() - cBaj;
			return reducedCost;
		}
	}
	
	/**
	 * Build the a route satisfy time windows constrain
	 */
	public Route buildOneLegalRoute(int startCust, int maxRouteSize) {
		Route currentRoute = new Route(); // stores the pointer to the current route
		Customer customerChosenPtr; // stores the pointer to the customer chosen from depots list assigned customers
		int customersNr;
		int startCustomer;
		int customerChosen; // serve to cycle j, j+1, ... assignedcustomersnr, 0, ... j-1

		// cycle the list of depots
			
		currentRoute.setDepot(this.vrptwInstance.getDepot());
		
		customersNr = this.vrptwInstance.getCustomersNr(); //tutti e "100" customer dell'istanza in ingresso
		if(startCust != -1) { //quindi il primo customer 锟� sempre randomico!!! fatto una sola volta nella prima iterazione (primo deposito) perch锟� le operazioni di get e set vengono fatte solamente qui (1 chiamata per ciascun metodo)
			startCustomer = startCust;
		}else{
			startCustomer = this.vrptwInstance.parameters.getRandom().nextInt(customersNr);
		}
		int chosenCustomersNr = 0;
		// cycle the entire list of customers starting from the randomly chosen one
		for (int j = startCustomer; j < customersNr + startCustomer; ++j) {
			// serve to cycle j, j+1, ... assignedcustomersnr, 0, ... j-1
			customerChosen = j % customersNr; //buffer circolare
			// stores the pointer to the customer chosen from depots list assigned customers
			customerChosenPtr = this.vrptwInstance.getCustomer(customerChosen); //si va a prendere il customer scelto all'indirizzo i-esimo nell'array
			// accept on the route only if satisfy the load and timeWindows
			if (customerChosenPtr.getDemand() + currentRoute.getLoad() <= vrptwInstance.getVehiclesCapacity() )  { 
				if(tryInsertBestTravelEndTW(currentRoute, customerChosenPtr, false)) {
					currentRoute.addLoad(customerChosenPtr.getDemand());
					chosenCustomersNr++;
				}
			}
			// cycle the routes until the maxRouteSize
			if(chosenCustomersNr >= maxRouteSize) {
				break;
			}
		} // end for customer list
		currentRoute.evaluateRoute(vrptwInstance);
		return currentRoute;
	}
	
	
	private boolean tryInsertBestTravelEndTW(Route route, Customer customerChosenPtr, boolean isForce) {
		int position = 0;
		if(route.isEmpty()){
			// add on first position
			position = 0;
		}else {
			// first position
			if(customerChosenPtr.getEndTw() <= route.getCustomer(0).getEndTw()) {
				position = 0;
			}
			
			// at the end
			if(route.getCustomer(route.getCustomersLength() - 1).getEndTw() <= customerChosenPtr.getEndTw()){
				position = route.getCustomersLength();
			}
			
			// try between each customer
			for(int i = 0; i < route.getCustomersLength() - 1; ++i) {
				if(route.getCustomer(i).getEndTw() <= customerChosenPtr.getEndTw() && customerChosenPtr.getEndTw() <= route.getCustomer(i + 1).getEndTw()) {
					position = i + 1;
				}
			}
		}
		
		route.addCustomer(new Customer(customerChosenPtr), position);
		if(isForce) {
			return true;
		}

		// try to insert
		double totalTime = 0;
    	double twViol = 0;
    	Customer customerK;
		
		if(!route.isEmpty()){
	    	// sum distances between each node in the route
			for (int k = 0; k < route.getCustomersLength(); ++k){
				// get the actual customer
				customerK = route.getCustomer(k);
				// add travel time to the route
				if(k == 0){
					totalTime += this.vrptwInstance.getTravelTime(route.getDepotNr(), customerK.getNumber());
				}else{
					totalTime += this.vrptwInstance.getTravelTime(route.getCustomerNr(k -1), customerK.getNumber());
				} // end if else
				
				totalTime = Math.max(customerK.getStartTw(), totalTime);
				// add time window violation if any
				twViol = Math.max(0, totalTime - customerK.getEndTw());
				
				if(twViol > 0) {
					route.removeCustomer(position);
					return false;
				}
				
				// add the service time to the total
				totalTime += customerK.getServiceDuration();				
			} // end for customers
			
			// add the distance to return to depot: from last node to depot
			totalTime += this.vrptwInstance.getTravelTime(route.getLastCustomerNr(), route.getDepotNr());
			// add the depot time window violation if any
			twViol = Math.max(0, totalTime - route.getDepot().getEndTw());
			
			if(twViol > 0) {
				route.removeCustomer(position);
				return false;
			}
									
		} // end if route not empty

		return true;
	}
	

	
	
	
	public void updateDualValues(Map<Customer,Double> dualValues) {
		this.rmpDualValues = dualValues;
	}
	
	public Route getRoute() {
		return this.route;
	}
}

